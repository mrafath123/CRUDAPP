require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const multer = require('multer');
const sharp = require('sharp');
const fs = require('fs').promises;
const fsSync = require('fs');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB Atlas'))
.catch(err => console.error('Error connecting to MongoDB:', err));

// ======================
// FILE HANDLING UTILITIES
// ======================
const safeDelete = async (filePath) => {
    try {
        await fs.access(filePath);
        await fs.unlink(filePath);
        console.log(`Successfully deleted ${filePath}`);
    } catch (err) {
        console.warn(`Could not delete ${filePath}:`, err.message);
    }
};

const ensureDirectoryExists = async (dirPath) => {
    try {
        await fs.access(dirPath);
    } catch {
        await fs.mkdir(dirPath, { recursive: true });
    }
};

// ======================
// IMAGE UPLOAD CONFIG (MULTIPLE FILES)
// ======================
const uploadDir = path.join(__dirname, 'public', 'uploads');
const tempDir = path.join(__dirname, 'temp_uploads');

// Create directories if they don't exist
(async () => {
    await ensureDirectoryExists(uploadDir);
    await ensureDirectoryExists(tempDir);
})();

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, tempDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    
    if (mimetype && extname) {
        cb(null, true);
    } else {
        cb(new Error('Error: Images only! (JPEG, JPG, PNG, GIF)'));
    }
};

// Updated to handle multiple files
const upload = multer({ 
    storage: storage,
    limits: { 
        fileSize: 5 * 1024 * 1024, // 5MB per file
        files: 10 // Maximum 10 files
    },
    fileFilter: fileFilter
}).array('images', 10); // 'images' field name, max 10 files

// ======================
// ITEM MODEL (UPDATED FOR MULTIPLE IMAGES)
// ======================
const itemSchema = new mongoose.Schema({
    name: String,
    description: String,
    price: Number,
    images: [String], // Array of image paths
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const Item = mongoose.model('Item', itemSchema);

// ======================
// ROUTES (UPDATED FOR MULTIPLE IMAGES)
// ======================

// Home - List all items
app.get('/', async (req, res) => {
    try {
        const items = await Item.find().sort({ createdAt: -1 });
        res.render('index', { 
            items,
            formatDate: (date) => date.toLocaleString() 
        });
    } catch (err) {
        console.error(err);
        res.status(500).render('error', { error: 'Failed to load items' });
    }
});

// Add Item Form
app.get('/add', (req, res) => {
    res.render('add', { error: null });
});

// Create Item (with multiple images)
app.post('/items', async (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.render('add', { 
                error: err.message,
                formData: req.body
            });
        }

        try {
            const imagePaths = [];
            
            // Process each uploaded file
            if (req.files && req.files.length > 0) {
                for (const file of req.files) {
                    try {
                        const resizedFilename = 'resized-' + path.basename(file.filename);
                        const outputPath = path.join(uploadDir, resizedFilename);
                        
                        await sharp(file.path)
                            .resize(500, 500, { fit: 'inside' })
                            .toFile(outputPath);
                        
                        imagePaths.push('/uploads/' + resizedFilename);
                    } finally {
                        await safeDelete(file.path);
                    }
                }
            }

            const newItem = new Item({
                name: req.body.name,
                description: req.body.description,
                price: req.body.price,
                images: imagePaths
            });

            await newItem.save();
            res.redirect('/');
        } catch (err) {
            console.error(err);
            res.render('add', { 
                error: 'Error saving item',
                formData: req.body
            });
        }
    });
});

// Edit Item Form
app.get('/edit/:id', async (req, res) => {
    try {
        const item = await Item.findById(req.params.id);
        if (!item) {
            return res.status(404).render('error', { error: 'Item not found' });
        }
        res.render('edit', { 
            item,
            formatDate: (date) => date.toLocaleString(),
            error: null
        });
    } catch (err) {
        console.error(err);
        res.status(500).render('error', { error: 'Failed to load item' });
    }
});

// Update Item (with multiple images)
app.post('/items/:id', async (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.render('edit', { 
                item: req.body, 
                error: err.message 
            });
        }

        try {
            const item = await Item.findById(req.params.id);
            if (!item) {
                return res.status(404).render('error', { error: 'Item not found' });
            }

            const updateData = {
                name: req.body.name,
                description: req.body.description,
                price: req.body.price,
                updatedAt: Date.now()
            };

            // Process new images if any
            if (req.files && req.files.length > 0) {
                const newImagePaths = [];
                
                for (const file of req.files) {
                    try {
                        const resizedFilename = 'resized-' + path.basename(file.filename);
                        const outputPath = path.join(uploadDir, resizedFilename);
                        
                        await sharp(file.path)
                            .resize(500, 500, { fit: 'inside' })
                            .toFile(outputPath);
                        
                        newImagePaths.push('/uploads/' + resizedFilename);
                    } finally {
                        await safeDelete(file.path);
                    }
                }
                
                // Combine existing images with new ones
                updateData.images = [...item.images, ...newImagePaths];
            }

            await Item.findByIdAndUpdate(req.params.id, updateData);
            res.redirect('/');
        } catch (err) {
            console.error(err);
            res.render('edit', { 
                item: req.body, 
                error: 'Error updating item' 
            });
        }
    });
});

// Delete Item (with image cleanup)
app.post('/items/delete/:id', async (req, res) => {
    try {
        const item = await Item.findByIdAndDelete(req.params.id);
        if (!item) {
            return res.status(404).render('error', { error: 'Item not found' });
        }
        
        // Delete all associated images
        if (item.images && item.images.length > 0) {
            for (const imagePath of item.images) {
                const fullPath = path.join(__dirname, 'public', imagePath);
                await safeDelete(fullPath);
            }
        }
        
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).render('error', { error: 'Failed to delete item' });
    }
});

// Delete Single Image
app.post('/items/:id/images/delete', async (req, res) => {
    try {
        const { imageUrl } = req.body;
        const item = await Item.findById(req.params.id);
        
        if (!item) {
            return res.status(404).json({ success: false, message: 'Item not found' });
        }
        
        // Remove image from array
        item.images = item.images.filter(img => img !== imageUrl);
        await item.save();
        
        // Delete file from server
        const imagePath = path.join(__dirname, 'public', imageUrl);
        await safeDelete(imagePath);
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to delete image' });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { error: 'Something went wrong!' });
});

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Upload directory: ${uploadDir}`);
    console.log(`Temp directory: ${tempDir}`);
});